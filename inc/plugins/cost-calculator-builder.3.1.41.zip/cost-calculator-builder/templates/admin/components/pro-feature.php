<div class="ccb-pro-feature">
	<div class="ccb-pro-feature__wrap">
		<div class="feature-container">
			<i class="fas fa-lock"></i>
			<p><?php esc_html_e( 'This feature is part of Premium Add-on', 'cost-calculator-builder' ); ?></p>
			<a href="https://stylemixthemes.com/cost-calculator-plugin/pricing/?utm_source=wpadmin&utm_medium=promo_calc&utm_campaign=2020" target="_blank"><?php esc_html_e( 'Buy now', 'cost-calculator-builder' ); ?></a>
		</div>
	</div>
</div>
