<?php 
/*
 Plugin Name: Logistic Services Posttyoe
 Plugin URI: https://www.themescaliber.com/
 Description: Creating new post type for Logistic Services Posttype Theme
 Author: Themescaliber
 Version: 1.0
 Author URI: https://www.themescaliber.com/
*/

define( 'LOGISTIC_SERVICES_POSTTYPE_VERSION', '1.0' );

add_action( 'init', 'createpackages');
add_action( 'init', 'logistic_services_posttype_create_post_type' );

function logistic_services_posttype_create_post_type() {
  register_post_type( 'workout',
    array(
        'labels' => array(
            'name' => __( 'Work Out','logistic-services-posttype' ),
            'singular_name' => __( ' Work Out','logistic-services-posttype' )
        ),
        'capability_type' =>  'post',
        'menu_icon'  => 'dashicons-tag',
        'public' => true,
        'supports' => array(
        'title',
        'editor',
        'thumbnail',
        'page-attributes',
        'comments'
        )
    )
  );
  register_post_type( 'testimonials',
  array(
    'labels' => array(
      'name' => __( 'Testimonials','logistic-services-posttype-pro' ),
      'singular_name' => __( 'Testimonials','logistic-services-posttype-pro' )
      ),
    'capability_type' => 'post',
    'menu_icon'  => 'dashicons-businessman',
    'public' => true,
    'supports' => array(
      'title',
      'editor',
      'thumbnail'
      )
    )
  );
}
function createpackages() {
  // Add new taxonomy, make it hierarchical (like categories)
  $labels = array(
    'name'              => __( 'Work Out Packages', 'logistic-services-posttype' ),
    'singular_name'     => __( 'Work Out Packages', 'logistic-services-posttype' ),
    'search_items'      => __( 'Search Cats', 'logistic-services-posttype' ),
    'all_items'         => __( 'All Work Out Packages', 'logistic-services-posttype' ),
    'parent_item'       => __( 'Parent Work Out Packages', 'logistic-services-posttype' ),
    'parent_item_colon' => __( 'Parent Work Out Packages:', 'logistic-services-posttype' ),
    'edit_item'         => __( 'Edit Work Out Packages', 'logistic-services-posttype' ),
    'update_item'       => __( 'Update Work out Packages', 'logistic-services-posttype' ),
    'add_new_item'      => __( 'Add New Work out Packages', 'logistic-services-posttype' ),
    'new_item_name'     => __( 'New Work Out Packages Name', 'logistic-services-posttype' ),
    'menu_name'         => __( 'Work Out Packages', 'logistic-services-posttype' ),
  );

  $args = array(
    'hierarchical'      => true,
    'labels'            => $labels,
    'show_ui'           => true,
    'show_admin_column' => true,
    'query_var'         => true,
    'rewrite'           => array( 'slug' => 'createpackages' ),
  );

  register_taxonomy( 'createpackages', array( 'workout' ), $args );
}
// Workout section
function logistic_services_posttype_images_metabox_enqueue($hook) {
  if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
    wp_enqueue_script('logistic-services-posttype-images-metabox', plugin_dir_url( __FILE__ ) . '/js/img-metabox.js', array('jquery', 'jquery-ui-sortable'));

    global $post;
    if ( $post ) {
      wp_enqueue_media( array(
          'post' => $post->ID,
        )
      );
    }
  }
}
add_action('admin_enqueue_scripts', 'logistic_services_posttype_images_metabox_enqueue');
// Work Out Meta
function logistic_services_posttype_bn_custom_meta_workout() {

    add_meta_box( 'bn_meta', __( 'Work Out Meta', 'logistic-services-posttype' ), 'logistic_services_posttype_bn_meta_callback_workout', 'workout', 'normal', 'high' );
}
/* Hook things in for admin*/
if (is_admin()){
  add_action('admin_menu', 'logistic_services_posttype_bn_custom_meta_workout');
}

function logistic_services_posttype_bn_meta_callback_workout( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'bn_nonce' );
    $bn_stored_meta = get_post_meta( $post->ID );
    ?>
  <div id="property_stuff">
    <table id="list-table">     
      <tbody id="the-list" data-wp-lists="list:meta">
        <tr id="meta-1">
          <p>
            <label for="meta-image"><?php echo esc_html('Icon Image'); ?></label><br>
            <input type="text" name="meta-image" id="meta-image" class="meta-image regular-text" value="<?php echo $bn_stored_meta['meta-image'][0]; ?>">
            <input type="button" class="button image-upload" value="Browse">
          </p>
          <div class="image-preview"><img src="<?php echo $bn_stored_meta['meta-image'][0]; ?>" style="max-width: 250px;"></div>
        </tr>
        <tr id="meta-3">
        <p>
          <label for="meta-timings"><?php echo esc_html('Add Timings'); ?></label><br>
          <input type="text" name="meta-timings" id="meta-timings" class="meta-timings regular-text" value="<?php echo $bn_stored_meta['meta-timings'][0]; ?>">
        </p>
      </tr>
        <tr id="meta-2">
          <p>
            <label for="meta-url"><?php echo esc_html('Want to link with custom URL'); ?></label><br>
            <input type="url" name="meta-url" id="meta-url" class="meta-url regular-text" value="<?php echo $bn_stored_meta['meta-url'][0]; ?>">
          </p>
        </tr>
      </tbody>
    </table>
  </div>
  <?php
}
function logistic_services_posttype_bn_meta_save_workout( $post_id ) {

  if (!isset($_POST['bn_nonce']) || !wp_verify_nonce($_POST['bn_nonce'], basename(__FILE__))) {
    return;
  }

  if (!current_user_can('edit_post', $post_id)) {
    return;
  }

  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return;
  }
  // Save Image
  if( isset( $_POST[ 'meta-image' ] ) ) {
      update_post_meta( $post_id, 'meta-image', esc_url_raw($_POST[ 'meta-image' ]) );
  }
  if( isset( $_POST[ 'meta-timings' ] ) ) {
      update_post_meta( $post_id, 'meta-timings', $_POST[ 'meta-timings' ] );
  }
  if( isset( $_POST[ 'meta-url' ] ) ) {
      update_post_meta( $post_id, 'meta-url', esc_url_raw($_POST[ 'meta-url' ]) );
  }
}
add_action( 'save_post', 'logistic_services_posttype_bn_meta_save_workout' );


/* Testimonial section */
/* Adds a meta box to the Testimonial editing screen */
function logistic_services_posttype_bn_testimonial_meta_box() {
  add_meta_box( 'logistic-services-posttype-pro-testimonial-meta', __( 'Enter Designation', 'logistic-services-posttype-pro' ), 'logistic_services_posttype_bn_testimonial_meta_callback', 'testimonials', 'normal', 'high' );
}
// Hook things in for admin
if (is_admin()){
    add_action('admin_menu', 'logistic_services_posttype_bn_testimonial_meta_box');
}

/* Adds a meta box for custom post */
function logistic_services_posttype_bn_testimonial_meta_callback( $post ) {
  wp_nonce_field( basename( __FILE__ ), 'logistic_services_posttype_posttype_testimonial_meta_nonce' );
  $bn_stored_meta = get_post_meta( $post->ID );
  $desigstory = get_post_meta( $post->ID, 'logistic_services_posttype_posttype_testimonial_desigstory', true );
  ?>
  <div id="testimonials_custom_stuff">
    <table id="list">
      <tbody id="the-list" data-wp-lists="list:meta">
        <tr id="meta-1">
          <td class="left">
            <?php esc_html_e( 'Designation', 'logistic-services-posttype-pro' )?>
          </td>
          <td class="left" >
            <input type="text" name="logistic_services_posttype_posttype_testimonial_desigstory" id="logistic_services_posttype_posttype_testimonial_desigstory" value="<?php echo esc_attr( $desigstory ); ?>" />
          </td>
        </tr>
        <tr id="meta-2">
          <td class="left">
            <?php esc_html_e( 'Want to link with custom URL', 'logistic-services-posttype' )?>
          </td>
          <td class="left" >
            <input type="url" name="meta-testimonial-url" id="meta-testimonial-url" class="meta-testimonial-url regular-text" value="<?php echo $bn_stored_meta['meta-testimonial-url'][0]; ?>">
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <?php
}

/* Saves the custom meta input */
function logistic_services_posttype_bn_metadesig_save( $post_id ) {
  if (!isset($_POST['logistic_services_posttype_posttype_testimonial_meta_nonce']) || !wp_verify_nonce($_POST['logistic_services_posttype_posttype_testimonial_meta_nonce'], basename(__FILE__))) {
    return;
  }

  if (!current_user_can('edit_post', $post_id)) {
    return;
  }

  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return;
  }

  // Save desig.
  if( isset( $_POST[ 'logistic_services_posttype_posttype_testimonial_desigstory' ] ) ) {
    update_post_meta( $post_id, 'logistic_services_posttype_posttype_testimonial_desigstory', sanitize_text_field($_POST[ 'logistic_services_posttype_posttype_testimonial_desigstory']) );
  }
  if( isset( $_POST[ 'meta-testimonial-url' ] ) ) {
    update_post_meta( $post_id, 'meta-testimonial-url', esc_url($_POST[ 'meta-testimonial-url']) );
  }

}

add_action( 'save_post', 'logistic_services_posttype_bn_metadesig_save' );

/* Testimonials shortcode */
function logistic_services_posttype_testimonial_func( $atts ) {
  $testimonial = '';
  $testimonial = '<div class="row">';
  $query = new WP_Query( array( 'post_type' => 'testimonials') );

    if ( $query->have_posts() ) :

  $k=1;
  $new = new WP_Query('post_type=testimonials');

  while ($new->have_posts()) : $new->the_post();
        $custom_url = '';
        $post_id = get_the_ID();
        $excerpt = wp_trim_words(get_the_excerpt(),25);
        $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post_id), 'large' );
        if(has_post_thumbnail()) { $thumb_url = $thumb['0']; }
        $desigstory= get_post_meta($post_id,'logistic_services_posttype_posttype_testimonial_desigstory',true);
        if(get_post_meta($post_id,'meta-testimonial-url',true !='')){$custom_url =get_post_meta($post_id,'meta-testimonial-url',true); } else{ $custom_url = get_permalink(); }
        $testimonial .= '
          <div class="col-md-6 col-sm-12">
            <div class=" testimonial_box_shortcode w-100 mb-4">
              <div class="image-box media">
                <img class="testi-img d-flex align-self-center mr-3" src="'.esc_url($thumb_url).'" alt="testimonial-thumbnail" />
                <div class="testimonial-box media-body">
                  <h4 class="testimonial_name mt-0"><a href="'.esc_url($custom_url).'">'.esc_html(get_the_title()) .'</a></h4>
                  <h5 class="border_heading" mt-0 mb-1>'.esc_html($desigstory).'</h5>
                   <div class="content_box w-100">
                    <div class="short_text pt-1"><p>'.$excerpt.'</p></div>
                  </div>
                </div>
              </div>
            </div>
          </div>';
    if($k%3 == 0){
      $testimonial.= '<div class="clearfix"></div>';
    }
      $k++;
  endwhile;
  else :
    $testimonial = '<h2 class="center">'.esc_html__('Post Not Found','logistic_services_store_pro_POSTTYPE_VERSION').'</h2>';
  endif;
  $testimonial .= '</div>';
  return $testimonial;
}

add_shortcode( 'testimonials', 'logistic_services_posttype_testimonial_func' );




/* Workout shortcode */
function logistic_services_posttype_workout_func( $atts ) {
  $workout = '';
  $workout = '<div class="row">';
  $query = new WP_Query( array( 'post_type' => 'workout') );

  if ( $query->have_posts() ) :

  $k=1;

  while ($query->have_posts()) : $query->the_post();
    $custom_url = '';
    $post_id = get_the_ID();
    $excerpt = wp_trim_words(get_the_excerpt(),25);
    $workout_img= get_post_meta($post_id,'meta-image',true);
    $timings= get_post_meta($post_id,'meta-timings',true);
    if(get_post_meta($post_id,'meta-url',true !='')){$custom_url =get_post_meta($post_id,'meta-url',true); } else{ $custom_url = get_permalink(); }
    $workout .= '
    <div class="col-md-4 col-lg-4 col-sm-6">
      <div class="workout_outers">
        <div class="workout_inner">
          <a href="'.esc_url($custom_url).'">
            <div class="row hover_border">
              <div class="col-md-12">
                <img class="workout-icons mt-3" src="'.esc_url($workout_img).'">
              </div>
              <div class="col-md-12">
                <p class="">'.get_the_title().'</p>
                <div class="short_text m-2">'.$excerpt.'</div>
                <div class="time mt-3 mb-3">'.$timings.'</div>
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>';
    if($k%3 == 0){
      $workout.= '<div class="clearfix"></div>';
    }
      $k++;
  endwhile;
  else :
    $workout = '<h2 class="center">'.esc_html__('Post Not Found','logistic_services_posttype').'</h2>';
  endif;
  $workout .= '</div>';
  return $workout;
}
add_shortcode( 'list-workout', 'logistic_services_posttype_workout_func' );

